import { useState } from 'react';

function App() {
  const [longUrl, setLongUrl] = useState('');
  const [shortcode, setShortcode] = useState('');
  const [validity, setValidity] = useState('');
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setResult('');

    const payload = {
      longUrl,
      validity: validity ? parseInt(validity) : 30,
    };
    if (shortcode) payload.shortcode = shortcode;

    try {
      const res = await fetch('http://localhost:3000/shorten', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (res.ok) setResult(data.shortUrl);
      else setError(data.error || 'Something went wrong');
    // eslint-disable-next-line no-unused-vars
    } catch (err) {
      setError('Network error');
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2>URL Shortener</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter Long URL"
          value={longUrl}
          onChange={(e) => setLongUrl(e.target.value)}
          required
        />
        <br /><br />
        <input
          type="text"
          placeholder="Custom Shortcode (optional)"
          value={shortcode}
          onChange={(e) => setShortcode(e.target.value)}
        />
        <br /><br />
        <input
          type="number"
          placeholder="Validity in minutes (default 30)"
          value={validity}
          onChange={(e) => setValidity(e.target.value)}
        />
        <br /><br />
        <button type="submit">Shorten</button>
      </form>

      {result && (
        <p>
          Short URL: <a href={result} target="_blank">{result}</a>
        </p>
      )}
      {error && (
        <p style={{ color: 'red' }}>{error}</p>
      )}
    </div>
  );
}

export default App;
